# AI Resume App

This is a full-stack app using React, Firebase, and Stripe.